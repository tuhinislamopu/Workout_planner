<!DOCTYPE html>
<html>
<head>
  <title>Workout & Diet Planner</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h2>🏋️ Workout & Diet Planner</h2>
  <ul>
    <li><a href="exercises/list.php">Manage Exercises</a></li>
    <li><a href="meals/list.php">Manage Meals</a></li>
    <li><a href="schedule/list.php">View Schedule</a></li>
    <li><a href="dashboard.php">View Dashboard</a></li>
  </ul>
</body>
</html>