<?php include("db.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <h2>Progress Dashboard</h2>
  <canvas id="calorieChart" width="400" height="200"></canvas>

<?php
$result = $conn->query("SELECT date, SUM(meals.calories) as total_cal 
                        FROM schedule 
                        JOIN meals ON schedule.meal_id = meals.id 
                        GROUP BY date");

$dates = [];
$calories = [];
while($row = $result->fetch_assoc()) {
    $dates[] = $row['date'];
    $calories[] = $row['total_cal'];
}
?>

<script>
let ctx = document.getElementById('calorieChart').getContext('2d');
let calorieChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($dates); ?>,
        datasets: [{
            label: 'Calories Intake',
            data: <?php echo json_encode($calories); ?>,
            borderColor: 'blue',
            fill: false
        }]
    }
});
</script>
</body>
</html>