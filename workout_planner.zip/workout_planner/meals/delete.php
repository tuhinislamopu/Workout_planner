<?php include("../db.php"); ?>
<?php
$id = $_GET['id'];
$conn->query("DELETE FROM meals WHERE id=$id");
header("Location: list.php");
?>