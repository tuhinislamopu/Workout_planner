<?php include("../db.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Meal</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h2>Add Meal</h2>
  <form method="POST">
    <input type="text" name="name" placeholder="Meal Name" required>
    <input type="text" name="category" placeholder="Category (e.g., Breakfast, Lunch)" required>
    <input type="number" name="calories" placeholder="Calories" required>
    <input type="number" name="protein" placeholder="Protein (g)" step="0.1">
    <input type="number" name="carbs" placeholder="Carbs (g)" step="0.1">
    <input type="number" name="fat" placeholder="Fat (g)" step="0.1">
    <button type="submit">Save</button>
  </form>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['name'];
  $category = $_POST['category'];
  $calories = $_POST['calories'];
  $protein = $_POST['protein'];
  $carbs = $_POST['carbs'];
  $fat = $_POST['fat'];

  $sql = "INSERT INTO meals (name, category, calories, protein, carbs, fat) 
          VALUES ('$name', '$category', '$calories', '$protein', '$carbs', '$fat')";
  if ($conn->query($sql)) {
    header("Location: list.php");
  } else {
    echo "Error: " . $conn->error;
  }
}
?>