<?php include("../db.php"); ?>
<?php
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM meals WHERE id=$id");
$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Meal</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h2>Edit Meal</h2>
  <form method="POST">
    <input type="text" name="name" value="<?php echo $row['name']; ?>" required>
    <input type="text" name="category" value="<?php echo $row['category']; ?>" required>
    <input type="number" name="calories" value="<?php echo $row['calories']; ?>" required>
    <input type="number" name="protein" value="<?php echo $row['protein']; ?>" step="0.1">
    <input type="number" name="carbs" value="<?php echo $row['carbs']; ?>" step="0.1">
    <input type="number" name="fat" value="<?php echo $row['fat']; ?>" step="0.1">
    <button type="submit">Update</button>
  </form>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['name'];
  $category = $_POST['category'];
  $calories = $_POST['calories'];
  $protein = $_POST['protein'];
  $carbs = $_POST['carbs'];
  $fat = $_POST['fat'];

  $sql = "UPDATE meals SET name='$name', category='$category', calories='$calories',
          protein='$protein', carbs='$carbs', fat='$fat' WHERE id=$id";
  if ($conn->query($sql)) {
    header("Location: list.php");
  } else {
    echo "Error: " . $conn->error;
  }
}
?>