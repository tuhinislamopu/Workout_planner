<?php include("../db.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Meals</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h2>Meals</h2>
  <a href="add.php">+ Add New Meal</a>
  <table>
    <tr>
      <th>ID</th><th>Name</th><th>Category</th><th>Calories</th><th>Protein</th><th>Carbs</th><th>Fat</th><th>Action</th>
    </tr>
    <?php
    $result = $conn->query("SELECT * FROM meals");
    while ($row = $result->fetch_assoc()) {
      echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['name']}</td>
        <td>{$row['category']}</td>
        <td>{$row['calories']} kcal</td>
        <td>{$row['protein']} g</td>
        <td>{$row['carbs']} g</td>
        <td>{$row['fat']} g</td>
        <td>
          <a href='edit.php?id={$row['id']}'>Edit</a> | 
          <a href='delete.php?id={$row['id']}'>Delete</a>
        </td>
      </tr>";
    }
    ?>
  </table>
</body>
</html>