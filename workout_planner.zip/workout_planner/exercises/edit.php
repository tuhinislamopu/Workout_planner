<?php include("../db.php"); ?>
<?php
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM exercises WHERE id=$id");
$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Exercise</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h2>Edit Exercise</h2>
  <form method="POST">
    <input type="text" name="name" value="<?php echo $row['name']; ?>" required>
    <input type="text" name="category" value="<?php echo $row['category']; ?>" required>
    <input type="number" name="duration" value="<?php echo $row['duration']; ?>" required>
    <input type="number" name="calories_burned" value="<?php echo $row['calories_burned']; ?>" required>
    <button type="submit">Update</button>
  </form>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['name'];
  $category = $_POST['category'];
  $duration = $_POST['duration'];
  $calories = $_POST['calories_burned'];

  $sql = "UPDATE exercises SET name='$name', category='$category', duration='$duration', calories_burned='$calories' WHERE id=$id";
  if ($conn->query($sql)) {
    header("Location: list.php");
  } else {
    echo "Error: " . $conn->error;
  }
}
?>