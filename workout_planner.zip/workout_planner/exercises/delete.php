<?php include("../db.php"); ?>
<?php
$id = $_GET['id'];
$conn->query("DELETE FROM exercises WHERE id=$id");
header("Location: list.php");
?>