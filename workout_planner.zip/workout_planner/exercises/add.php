<?php include("../db.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Exercise</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h2>Add Exercise</h2>
  <form method="POST">
    <input type="text" name="name" placeholder="Exercise Name" required>
    <input type="text" name="category" placeholder="Category" required>
    <input type="number" name="duration" placeholder="Duration (min)" required>
    <input type="number" name="calories_burned" placeholder="Calories Burned" required>
    <button type="submit">Save</button>
  </form>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['name'];
  $category = $_POST['category'];
  $duration = $_POST['duration'];
  $calories = $_POST['calories_burned'];

  $sql = "INSERT INTO exercises (name, category, duration, calories_burned) 
          VALUES ('$name', '$category', '$duration', '$calories')";
  if ($conn->query($sql)) {
    header("Location: list.php");
  } else {
    echo "Error: " . $conn->error;
  }
}
?>