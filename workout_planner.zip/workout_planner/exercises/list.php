<?php include("../db.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Exercises</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h2>Exercises</h2>
  <a href="add.php">+ Add New Exercise</a>
  <table>
    <tr>
      <th>ID</th><th>Name</th><th>Category</th><th>Duration</th><th>Calories</th><th>Action</th>
    </tr>
    <?php
    $result = $conn->query("SELECT * FROM exercises");
    while ($row = $result->fetch_assoc()) {
      echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['name']}</td>
        <td>{$row['category']}</td>
        <td>{$row['duration']} min</td>
        <td>{$row['calories_burned']} kcal</td>
        <td>
          <a href='edit.php?id={$row['id']}'>Edit</a> | 
          <a href='delete.php?id={$row['id']}'>Delete</a>
        </td>
      </tr>";
    }
    ?>
  </table>
</body>
</html>