<?php include("../db.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Schedule</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h2>Workout + Meal Schedule</h2>
  <a href="add.php">+ Add Schedule</a>
  <table>
    <tr>
      <th>Date</th><th>Exercise</th><th>Meal</th>
    </tr>
    <?php
    $result = $conn->query("SELECT schedule.date, exercises.name as ex, meals.name as meal
                            FROM schedule 
                            JOIN exercises ON schedule.exercise_id = exercises.id
                            JOIN meals ON schedule.meal_id = meals.id");
    while ($row = $result->fetch_assoc()) {
      echo "<tr>
        <td>{$row['date']}</td>
        <td>{$row['ex']}</td>
        <td>{$row['meal']}</td>
      </tr>";
    }
    ?>
  </table>
</body>
</html>