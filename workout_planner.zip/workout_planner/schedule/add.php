<?php include("../db.php"); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Schedule</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <h2>Schedule Workout + Meal</h2>
  <form method="POST">
    <label>Select Exercise</label>
    <select name="exercise_id">
      <?php
      $ex = $conn->query("SELECT * FROM exercises");
      while ($row = $ex->fetch_assoc()) {
        echo "<option value='{$row['id']}'>{$row['name']}</option>";
      }
      ?>
    </select>

    <label>Select Meal</label>
    <select name="meal_id">
      <?php
      $me = $conn->query("SELECT * FROM meals");
      while ($row = $me->fetch_assoc()) {
        echo "<option value='{$row['id']}'>{$row['name']}</option>";
      }
      ?>
    </select>

    <label>Date</label>
    <input type="date" name="date" required>
    <button type="submit">Save</button>
  </form>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $exercise_id = $_POST['exercise_id'];
  $meal_id = $_POST['meal_id'];
  $date = $_POST['date'];

  $sql = "INSERT INTO schedule (user_id, exercise_id, meal_id, date) VALUES (1, '$exercise_id', '$meal_id', '$date')";
  if ($conn->query($sql)) {
    header("Location: list.php");
  } else {
    echo "Error: " . $conn->error;
  }
}
?>